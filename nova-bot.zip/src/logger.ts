export const logger = {
  info: (msg: any, ...args: any[]) => {
    console.log(`[${new Date().toISOString()}] INFO:`, msg, ...args);
  },
  warn: (msg: any, ...args: any[]) => {
    console.warn(`[${new Date().toISOString()}] WARN:`, msg, ...args);
  },
  error: (msg: any, ...args: any[]) => {
    console.error(`[${new Date().toISOString()}] ERROR:`, msg, ...args);
  },
};
