import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

const sqlite = new Database("sqlite.db");
export const db = drizzle(sqlite);

export const novaRulesTable = sqliteTable("novaRules", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  guildId: text("guildId").notNull(),
  content: text("content").notNull(),
  createdAt: integer("createdAt", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
});

export const novaLinksTable = sqliteTable("novaLinks", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  guildId: text("guildId").notNull(),
  label: text("label").notNull(),
  url: text("url").notNull(),
  addedBy: text("addedBy").notNull(),
  createdAt: integer("createdAt", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
});

export const novaConfigTable = sqliteTable("novaConfig", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  guildId: text("guildId").notNull().unique(),
  logChannelId: text("logChannelId"),
  updatedAt: integer("updatedAt", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
});
