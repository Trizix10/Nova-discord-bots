import {
  Client,
  GatewayIntentBits,
  Partials,
  Events,
  PermissionFlagsBits,
  ChannelType,
  AuditLogEvent,
  REST,
  Routes,
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
  type TextChannel,
  type Message,
  type GuildMember,
  type Guild,
  type ChatInputCommandInteraction,
} from "discord.js";
import Anthropic from "@anthropic-ai/sdk";
import { db, novaRulesTable, novaLinksTable, novaConfigTable } from "./db.js";
import { eq, and } from "drizzle-orm";
import { logger } from "./logger.js";
import "dotenv/config";

const SLOWMODE_SECONDS = 5;
const SPAM_WINDOW_MS = 5000;
const SPAM_MAX_MESSAGES = 5;
const ANTI_NUKE_THRESHOLD = 3;
const ANTI_NUKE_WINDOW_MS = 10000;
const DISCORD_MAX_LENGTH = 1900;

const INSULTS_FR_EN = [
  "pute","putain","merde","connard","connasse","salope","enculé","enculer","bâtard","batard",
  "niquer","nique","fdp","fils de pute","ta gueule","gueule","pd","pédé","tapette",
  "con","conne","idiot","idiote","imbécile","abruti","débile","crétin","crétine",
  "grosse vache","grosse merde","va chier","aller se faire foutre","foutre",
  "shut up","fuck","shit","bitch","asshole","bastard","cunt","dick","pussy",
  "motherfucker","faggot","retard","dumbass","dipshit","jackass","whore","slut",
  "niger","nigger","nigga","kill yourself","kys","go die","loser",
  "ta mere","ta mère","ton pere","ton père","bouffon","clochard","dechet","déchet",
  "ordure","salopard","saloparde","espece de","espèce de","sale","maudit","maudite",
  "ostie","câlisse","tabarnak","hostie","crisse","câline","sacrement","viarge","estie",
];

const URL_REGEX = /https?:\/\/\S+|discord\.gg\/\S+|www\.\S+\.\S+/gi;
const userMessageTimes = new Map<string, number[]>();
const nukeActionsMap = new Map<string, { count: number; firstTime: number }>();
const conversationHistory = new Map<string, { role: "user" | "assistant"; content: string }[]>();

const logChannelCache = new Map<string, string | null>();

async function getLogChannelId(guildId: string): Promise<string | null> {
  if (logChannelCache.has(guildId)) return logChannelCache.get(guildId) ?? null;
  const [cfg] = await db.select().from(novaConfigTable).where(eq(novaConfigTable.guildId, guildId));
  const id = cfg?.logChannelId ?? null;
  logChannelCache.set(guildId, id);
  return id;
}

async function sendLog(client: Client, guildId: string, embed: EmbedBuilder) {
  try {
    const channelId = await getLogChannelId(guildId);
    if (!channelId) return;
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (channel && "send" in channel) {
      await (channel as TextChannel).send({ embeds: [embed] });
    }
  } catch (err) {
    logger.warn("Failed to send mod log", err, guildId);
  }
}

function containsInsult(text: string): boolean {
  const lower = text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  return INSULTS_FR_EN.some(insult => {
    const n = insult.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    return new RegExp(`\\b${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i").test(lower);
  });
}

function containsLink(text: string): boolean {
  URL_REGEX.lastIndex = 0;
  return URL_REGEX.test(text);
}

function containsEveryoneSpam(text: string): boolean {
  return /@everyone|@here/.test(text);
}

function isSpamming(userId: string): boolean {
  const now = Date.now();
  const times = (userMessageTimes.get(userId) ?? []).filter(t => now - t < SPAM_WINDOW_MS);
  times.push(now);
  userMessageTimes.set(userId, times);
  return times.length > SPAM_MAX_MESSAGES;
}

async function applySlowmodeToAll(guild: Guild) {
  for (const [, channel] of guild.channels.cache) {
    if (
      channel.type === ChannelType.GuildText ||
      channel.type === ChannelType.GuildForum ||
      channel.type === ChannelType.GuildAnnouncement
    ) {
      try {
        const tc = channel as TextChannel;
        if (tc.rateLimitPerUser !== SLOWMODE_SECONDS) {
          await tc.setRateLimitPerUser(SLOWMODE_SECONDS, "AutoMod: slowmode permanent");
        }
      } catch {}
    }
  }
}

async function warnAndDelete(client: Client, message: Message, reason: string) {
  const guildId = message.guild?.id;
  try { await message.delete(); } catch {}
  try {
    if ("send" in message.channel) {
      const w = await message.channel.send(
        `<@${message.author.id}> **[AUTOMOD]** Message supprimé — ${reason}`
      );
      setTimeout(() => w.delete().catch(() => {}), 5000);
    }
  } catch {}
  if (guildId) {
    await sendLog(client, guildId, new EmbedBuilder()
      .setColor(Colors.Orange)
      .setTitle("🗑️ AutoMod — Message supprimé")
      .addFields(
        { name: "Utilisateur", value: `<@${message.author.id}> (${message.author.tag})`, inline: true },
        { name: "Salon", value: `<#${message.channelId}>`, inline: true },
        { name: "Raison", value: reason, inline: false },
        { name: "Contenu", value: message.content ? `\`\`\`${message.content.slice(0, 900)}\`\`\`` : "_vide_", inline: false },
      )
      .setTimestamp()
      .setFooter({ text: "NOVA AutoMod" })
    );
  }
}

async function timeoutMember(client: Client, member: GuildMember, reason: string, durationMs = 60000) {
  if (!member || member.user.bot) return;
  try {
    if (!member.isCommunicationDisabled()) {
      await member.timeout(durationMs, reason);
      await sendLog(client, member.guild.id, new EmbedBuilder()
        .setColor(Colors.Yellow)
        .setTitle("⏱️ AutoMod — Timeout appliqué")
        .addFields(
          { name: "Utilisateur", value: `<@${member.id}> (${member.user.tag})`, inline: true },
          { name: "Durée", value: `${Math.round(durationMs / 60000)} minute(s)`, inline: true },
          { name: "Raison", value: reason, inline: false },
        )
        .setTimestamp()
        .setFooter({ text: "NOVA AutoMod" })
      );
    }
  } catch (err) { logger.warn("Could not timeout member", err, member.id); }
}

async function handleAntiNuke(client: Client, guild: Guild, userId: string, actionType: string) {
  const key = `${guild.id}:${userId}`;
  const now = Date.now();
  const entry = nukeActionsMap.get(key) ?? { count: 0, firstTime: now };
  if (now - entry.firstTime > ANTI_NUKE_WINDOW_MS) {
    nukeActionsMap.set(key, { count: 1, firstTime: now }); return;
  }
  entry.count += 1;
  nukeActionsMap.set(key, entry);
  if (entry.count >= ANTI_NUKE_THRESHOLD) {
    logger.warn("Anti-nuke triggered", userId, actionType, guild.id);
    let sanctionApplied = "Aucune sanction (admin)";
    try {
      const member = await guild.members.fetch(userId).catch(() => null);
      if (member && !member.permissions.has(PermissionFlagsBits.Administrator)) {
        await guild.bans.create(userId, { reason: `[AUTOMOD] Nuke: ${actionType}` });
        sanctionApplied = "BAN permanent";
      } else if (member) {
        await member.timeout(28 * 24 * 60 * 60 * 1000, `[AUTOMOD] Nuke: ${actionType}`);
        sanctionApplied = "Timeout 28 jours (Admin — impossible de ban)";
      }
      guild.systemChannel?.send(
        `**[ANTI-NUKE]** Action suspecte de <@${userId}> — \`${actionType}\`. Sanction automatique appliquée.`
      );
    } catch (err) { logger.error("Anti-nuke action failed", err, userId); }
    await sendLog(client, guild.id, new EmbedBuilder()
      .setColor(Colors.Red)
      .setTitle("🚨 Anti-Nuke déclenché")
      .addFields(
        { name: "Coupable", value: `<@${userId}>`, inline: true },
        { name: "Action détectée", value: actionType, inline: true },
        { name: "Sanction", value: sanctionApplied, inline: false },
        { name: "Seuil", value: `${ANTI_NUKE_THRESHOLD} actions en ${ANTI_NUKE_WINDOW_MS / 1000}s`, inline: true },
      )
      .setTimestamp()
      .setFooter({ text: "NOVA Anti-Nuke" })
    );
    nukeActionsMap.delete(key);
  }
}

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY ?? "missing",
});

const AI_MODEL = "claude-3-5-sonnet-20241022";

function splitLongMessage(text: string): string[] {
  const chunks: string[] = [];
  while (text.length > 0) {
    chunks.push(text.slice(0, DISCORD_MAX_LENGTH));
    text = text.slice(DISCORD_MAX_LENGTH);
  }
  return chunks;
}

async function askClaude(channelId: string, userMessage: string, username: string): Promise<string> {
  const history = conversationHistory.get(channelId) ?? [];
  history.push({ role: "user", content: `${username}: ${userMessage}` });
  if (history.length > 20) history.splice(0, history.length - 20);
  conversationHistory.set(channelId, history);
  const response = await anthropic.messages.create({
    model: AI_MODEL,
    max_tokens: 8192,
    system: "Tu es NOVA, un assistant IA intégré à Discord. Tu es intelligent, utile, direct et légèrement sarcastique quand c'est approprié. Tu parles la même langue que l'utilisateur (français ou anglais). Ne te présente pas à chaque message. Sois concis mais complet.",
    messages: history,
  });
  const text = response.content[0].type === "text"
    ? response.content[0].text
    : "Je n'ai pas pu générer de réponse.";
  history.push({ role: "assistant", content: text });
  conversationHistory.set(channelId, history);
  return text;
}

async function handleNovaSetlogs(interaction: ChatInputCommandInteraction, client: Client) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({ content: "Tu dois être Administrateur pour configurer les logs.", ephemeral: true }); return;
  }
  const channel = interaction.options.getChannel("salon", true);
  if (channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: "Sélectionne un salon texte.", ephemeral: true }); return;
  }
  const guildId = interaction.guildId!;
  await db.insert(novaConfigTable)
    .values({ guildId, logChannelId: channel.id })
    .onConflictDoUpdate({ target: novaConfigTable.guildId, set: { logChannelId: channel.id, updatedAt: new Date() } });
  logChannelCache.set(guildId, channel.id);
  await interaction.reply({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Green)
      .setTitle("✅ Salon de logs configuré")
      .setDescription(`Tous les logs de modération seront envoyés dans <#${channel.id}>.`)
      .setTimestamp()],
  });
  await sendLog(client, guildId, new EmbedBuilder()
    .setColor(Colors.Purple)
    .setTitle("📋 Logs NOVA activés")
    .setDescription(`Ce salon a été configuré comme salon de logs par <@${interaction.user.id}>.`)
    .setTimestamp()
    .setFooter({ text: "NOVA Logs" })
  );
}

async function handleNovaAsk(interaction: ChatInputCommandInteraction) {
  const question = interaction.options.getString("question", true);
  await interaction.deferReply();
  try {
    const answer = await askClaude(interaction.channelId, question, interaction.user.username);
    const chunks = splitLongMessage(answer);
    await interaction.editReply(chunks[0]);
    for (let i = 1; i < chunks.length; i++) await interaction.followUp(chunks[i]);
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.error("nova-ask error", err, detail);
    await interaction.editReply(`Erreur IA : \`${detail.slice(0, 300)}\``);
  }
}

async function handleNovaBan(interaction: ChatInputCommandInteraction, client: Client) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.BanMembers)) {
    await interaction.reply({ content: "Tu n'as pas la permission de bannir.", ephemeral: true }); return;
  }
  const target = interaction.options.getMember("utilisateur") as GuildMember | null;
  const reason = interaction.options.getString("raison") ?? "Aucune raison fournie";
  if (!target) { await interaction.reply({ content: "Utilisateur introuvable.", ephemeral: true }); return; }
  if (!target.bannable) { await interaction.reply({ content: "Je ne peux pas bannir cet utilisateur.", ephemeral: true }); return; }
  await target.ban({ reason: `[NOVA] ${reason} — par ${interaction.user.tag}` });
  const embed = new EmbedBuilder().setColor(Colors.Red).setTitle("🔨 Utilisateur banni")
    .addFields(
      { name: "Utilisateur", value: `<@${target.id}> (${target.user.tag})`, inline: true },
      { name: "Modérateur", value: `<@${interaction.user.id}>`, inline: true },
      { name: "Raison", value: reason, inline: false },
    ).setTimestamp().setFooter({ text: "NOVA Modération" });
  await interaction.reply({ embeds: [embed] });
  await sendLog(client, interaction.guildId!, embed);
}

async function handleNovaKick(interaction: ChatInputCommandInteraction, client: Client) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.KickMembers)) {
    await interaction.reply({ content: "Tu n'as pas la permission d'expulser.", ephemeral: true }); return;
  }
  const target = interaction.options.getMember("utilisateur") as GuildMember | null;
  const reason = interaction.options.getString("raison") ?? "Aucune raison fournie";
  if (!target) { await interaction.reply({ content: "Utilisateur introuvable.", ephemeral: true }); return; }
  if (!target.kickable) { await interaction.reply({ content: "Je ne peux pas expulser cet utilisateur.", ephemeral: true }); return; }
  await target.kick(`[NOVA] ${reason} — par ${interaction.user.tag}`);
  const embed = new EmbedBuilder().setColor(Colors.Orange).setTitle("👢 Utilisateur expulsé")
    .addFields(
      { name: "Utilisateur", value: `<@${target.id}> (${target.user.tag})`, inline: true },
      { name: "Modérateur", value: `<@${interaction.user.id}>`, inline: true },
      { name: "Raison", value: reason, inline: false },
    ).setTimestamp().setFooter({ text: "NOVA Modération" });
  await interaction.reply({ embeds: [embed] });
  await sendLog(client, interaction.guildId!, embed);
}

async function handleNovaMute(interaction: ChatInputCommandInteraction, client: Client) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) {
    await interaction.reply({ content: "Tu n'as pas la permission de mettre en sourdine.", ephemeral: true }); return;
  }
  const target = interaction.options.getMember("utilisateur") as GuildMember | null;
  const dureeMin = interaction.options.getInteger("duree") ?? 10;
  const reason = interaction.options.getString("raison") ?? "Aucune raison fournie";
  if (!target) { await interaction.reply({ content: "Utilisateur introuvable.", ephemeral: true }); return; }
  if (!target.moderatable) { await interaction.reply({ content: "Je ne peux pas muter cet utilisateur.", ephemeral: true }); return; }
  await target.timeout(dureeMin * 60 * 1000, `[NOVA] ${reason} — par ${interaction.user.tag}`);
  const embed = new EmbedBuilder().setColor(Colors.Yellow).setTitle("⏱️ Utilisateur mute")
    .addFields(
      { name: "Utilisateur", value: `<@${target.id}> (${target.user.tag})`, inline: true },
      { name: "Durée", value: `${dureeMin} minute(s)`, inline: true },
      { name: "Modérateur", value: `<@${interaction.user.id}>`, inline: true },
      { name: "Raison", value: reason, inline: false },
    ).setTimestamp().setFooter({ text: "NOVA Modération" });
  await interaction.reply({ embeds: [embed] });
  await sendLog(client, interaction.guildId!, embed);
}

async function handleNovaClear(interaction: ChatInputCommandInteraction, client: Client) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages)) {
    await interaction.reply({ content: "Tu n'as pas la permission de supprimer des messages.", ephemeral: true }); return;
  }
  const amount = Math.min(interaction.options.getInteger("nombre", true), 100);
  const channel = interaction.channel as TextChannel;
  if (!channel) { await interaction.reply({ content: "Salon introuvable.", ephemeral: true }); return; }
  const deleted = await channel.bulkDelete(amount, true);
  const embed = new EmbedBuilder().setColor(Colors.Purple).setTitle("🧹 Messages supprimés")
    .addFields(
      { name: "Quantité", value: `${deleted.size} message(s)`, inline: true },
      { name: "Salon", value: `<#${channel.id}>`, inline: true },
      { name: "Modérateur", value: `<@${interaction.user.id}>`, inline: true },
    ).setTimestamp().setFooter({ text: "NOVA Modération" });
  await interaction.reply({ embeds: [embed], ephemeral: true });
  await sendLog(client, interaction.guildId!, embed);
}

async function handleNovaPing(interaction: ChatInputCommandInteraction) {
  await interaction.reply({
    embeds: [new EmbedBuilder().setColor(Colors.Purple).setTitle("🏓 NOVA — Latence")
      .addFields(
        { name: "Latence Bot", value: `${Date.now() - interaction.createdTimestamp}ms`, inline: true },
        { name: "Latence WebSocket", value: `${interaction.client.ws.ping}ms`, inline: true },
      ).setTimestamp()],
  });
}

async function handleNovaUserinfo(interaction: ChatInputCommandInteraction) {
  const target = interaction.options.getMember("utilisateur") as GuildMember
    ?? interaction.member as GuildMember;
  if (!target) { await interaction.reply({ content: "Utilisateur introuvable.", ephemeral: true }); return; }
  const user = target.user;
  const roles = target.roles.cache
    .filter(r => r.name !== "@everyone")
    .map(r => `<@&${r.id}>`)
    .join(", ") || "Aucun";
  await interaction.reply({
    embeds: [new EmbedBuilder().setColor(Colors.Purple).setTitle(`👤 ${user.tag}`)
      .setThumbnail(user.displayAvatarURL())
      .addFields(
        { name: "ID", value: user.id, inline: true },
        { name: "Surnom", value: target.nickname ?? "Aucun", inline: true },
        { name: "Compte créé", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: "A rejoint", value: target.joinedAt ? `<t:${Math.floor(target.joinedAt.getTime() / 1000)}:R>` : "Inconnu", inline: true },
        { name: "Bot", value: user.bot ? "Oui" : "Non", inline: true },
        { name: `Rôles (${target.roles.cache.size - 1})`, value: roles.length > 1000 ? roles.slice(0, 997) + "..." : roles, inline: false },
      ).setTimestamp()],
  });
}

async function handleNovaServerinfo(interaction: ChatInputCommandInteraction) {
  const guild = interaction.guild!;
  await guild.fetch();
  const owner = await guild.fetchOwner().catch(() => null);
  await interaction.reply({
    embeds: [new EmbedBuilder().setColor(Colors.Purple).setTitle(`🏠 ${guild.name}`)
      .setThumbnail(guild.iconURL())
      .addFields(
        { name: "ID", value: guild.id, inline: true },
        { name: "Propriétaire", value: owner ? owner.user.tag : "Inconnu", inline: true },
        { name: "Créé", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
        { name: "Membres", value: `${guild.memberCount}`, inline: true },
        { name: "Salons", value: `${guild.channels.cache.size}`, inline: true },
        { name: "Rôles", value: `${guild.roles.cache.size}`, inline: true },
        { name: "Emojis", value: `${guild.emojis.cache.size}`, inline: true },
        { name: "Boost", value: `Niveau ${guild.premiumTier} (${guild.premiumSubscriptionCount} boosts)`, inline: true },
      ).setTimestamp()],
  });
}

async function handleNovaHelp(interaction: ChatInputCommandInteraction) {
  await interaction.reply({
    embeds: [new EmbedBuilder().setColor(Colors.Purple).setTitle("📖 NOVA — Toutes les commandes")
      .addFields(
        { name: "🤖 IA", value: "`/nova-ask` — Poser une question à Claude\nMentionner NOVA — Conversation libre avec l'IA", inline: false },
        { name: "🔨 Modération", value: [
          "`/nova-ban @user [raison]` — Bannir",
          "`/nova-kick @user [raison]` — Expulser",
          "`/nova-mute @user [durée] [raison]` — Timeout",
          "`/nova-clear <nombre>` — Supprimer des messages",
        ].join("\n"), inline: false },
        { name: "📊 Informations", value: [
          "`/nova-ping` — Latence du bot",
          "`/nova-userinfo [@user]` — Infos d'un membre",
          "`/nova-serverinfo` — Infos du serveur",
        ].join("\n"), inline: false },
        { name: "📋 Règles & Liens", value: [
          "`/nova-rules action:add/show/clear` — Gérer les règles",
          "`/nova-links-add label url` — Enregistrer un lien",
          "`/nova-links-delete id` — Supprimer un lien",
          "`/nova-links-look` — Voir tous les liens",
        ].join("\n"), inline: false },
        { name: "⚙️ Configuration", value: "`/nova-setlogs #salon` — Définir le salon des logs (Admin)", inline: false },
        { name: "🛡️ AutoMod H24", value: [
          "• Anti-lien → suppression + timeout 5 min",
          "• Anti-@everyone/@here → timeout 10 min",
          "• Anti-spam → timeout 5 min",
          "• Anti-insulte FR/EN → timeout 10 min",
          "• Slowmode permanent 5s",
          "• Anti-nuke → ban auto si 3 actions en 10s",
        ].join("\n"), inline: false },
      ).setFooter({ text: "NOVA Security & AI Bot" }).setTimestamp()],
  });
}

async function handleNovaRules(interaction: ChatInputCommandInteraction) {
  const action = interaction.options.getString("action", true);
  const guildId = interaction.guildId!;
  if (action === "add") {
    const content = interaction.options.getString("contenu", true);
    await db.insert(novaRulesTable).values({ guildId, content });
    const rules = await db.select().from(novaRulesTable)
      .where(eq(novaRulesTable.guildId, guildId)).orderBy(novaRulesTable.id);
    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(Colors.Green).setTitle("✅ Règle ajoutée")
        .addFields({ name: `Règle #${rules.length}`, value: content })],
    });
    return;
  }
  if (action === "show") {
    const rules = await db.select().from(novaRulesTable)
      .where(eq(novaRulesTable.guildId, guildId)).orderBy(novaRulesTable.id);
    if (rules.length === 0) {
      await interaction.reply({ content: "Aucune règle. Utilise `/nova-rules action:add`.", ephemeral: true }); return;
    }
    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(Colors.Purple).setTitle(`📋 Règles — ${rules.length}`)
        .setDescription(rules.map((r, i) => `**${i + 1}.** ${r.content}`).join("\n\n")).setTimestamp()],
    });
    return;
  }
  if (action === "clear") {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      await interaction.reply({ content: "Admin requis.", ephemeral: true }); return;
    }
    await db.delete(novaRulesTable).where(eq(novaRulesTable.guildId, guildId));
    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setTitle("🗑️ Règles effacées")
        .setDescription("Toutes les règles ont été supprimées.")],
    });
  }
}

async function handleNovaLinksAdd(interaction: ChatInputCommandInteraction) {
  const label = interaction.options.getString("label", true);
  const url = interaction.options.getString("url", true);
  if (!/^https?:\/\/.+/.test(url)) {
    await interaction.reply({ content: "URL invalide (doit commencer par http:// ou https://).", ephemeral: true }); return;
  }
  const [link] = await db.insert(novaLinksTable)
    .values({ guildId: interaction.guildId!, label, url, addedBy: interaction.user.tag }).returning();
  await interaction.reply({
    embeds: [new EmbedBuilder().setColor(Colors.Green).setTitle("🔗 Lien enregistré")
      .addFields(
        { name: "ID", value: `\`${link.id}\``, inline: true },
        { name: "Nom", value: label, inline: true },
        { name: "URL", value: url },
      )],
  });
}

async function handleNovaLinksDelete(interaction: ChatInputCommandInteraction) {
  const id = interaction.options.getInteger("id", true);
  const [deleted] = await db.delete(novaLinksTable)
    .where(and(eq(novaLinksTable.id, id), eq(novaLinksTable.guildId, interaction.guildId!)))
    .returning();
  if (!deleted) {
    await interaction.reply({ content: `Aucun lien avec l'ID \`${id}\`.`, ephemeral: true }); return;
  }
  await interaction.reply({
    embeds: [new EmbedBuilder().setColor(Colors.Red).setTitle("🗑️ Lien supprimé")
      .setDescription(`**${deleted.label}** (ID \`${deleted.id}\`) supprimé.`)],
  });
}

async function handleNovaLinksLook(interaction: ChatInputCommandInteraction) {
  const links = await db.select().from(novaLinksTable)
    .where(eq(novaLinksTable.guildId, interaction.guildId!)).orderBy(novaLinksTable.id);
  if (links.length === 0) {
    await interaction.reply({ content: "Aucun lien. Utilise `/nova-links-add`.", ephemeral: true }); return;
  }
  await interaction.reply({
    embeds: [new EmbedBuilder().setColor(Colors.Purple).setTitle(`🔗 Liens — ${links.length}`)
      .setDescription(links.map(l => `**[${l.id}]** [${l.label}](${l.url}) — par ${l.addedBy}`).join("\n\n"))
      .setTimestamp()],
  });
}

export function startModerationBot() {
  const token = process.env.DISCORD_AI_BOT_TOKEN;
  if (!token) { logger.warn("DISCORD_AI_BOT_TOKEN not set — moderation bot not started"); return; }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildModeration,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client.once(Events.ClientReady, async (c) => {
    logger.info("Moderation bot online", c.user.tag);

    const commands = [
      new SlashCommandBuilder().setName("nova-help").setDescription("Toutes les commandes NOVA").toJSON(),
      new SlashCommandBuilder().setName("nova-setlogs")
        .setDescription("Définir le salon des logs de modération (Admin)")
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addChannelOption(o => o.setName("salon").setDescription("Le salon texte").addChannelTypes(ChannelType.GuildText).setRequired(true)).toJSON(),
      new SlashCommandBuilder().setName("nova-ask")
        .setDescription("Poser une question à l'IA Claude")
        .addStringOption(o => o.setName("question").setDescription("Ta question").setRequired(true)).toJSON(),
      new SlashCommandBuilder().setName("nova-ban")
        .setDescription("Bannir un utilisateur")
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
        .addUserOption(o => o.setName("utilisateur").setDescription("L'utilisateur").setRequired(true))
        .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)).toJSON(),
      new SlashCommandBuilder().setName("nova-kick")
        .setDescription("Expulser un utilisateur")
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
        .addUserOption(o => o.setName("utilisateur").setDescription("L'utilisateur").setRequired(true))
        .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)).toJSON(),
      new SlashCommandBuilder().setName("nova-mute")
        .setDescription("Timeout un utilisateur")
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
        .addUserOption(o => o.setName("utilisateur").setDescription("L'utilisateur").setRequired(true))
        .addIntegerOption(o => o.setName("duree").setDescription("Durée en minutes (défaut: 10)").setMinValue(1).setMaxValue(40320).setRequired(false))
        .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)).toJSON(),
      new SlashCommandBuilder().setName("nova-clear")
        .setDescription("Supprimer des messages en masse")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addIntegerOption(o => o.setName("nombre").setDescription("Nombre (max 100)").setMinValue(1).setMaxValue(100).setRequired(true)).toJSON(),
      new SlashCommandBuilder().setName("nova-ping").setDescription("Latence de NOVA").toJSON(),
      new SlashCommandBuilder().setName("nova-userinfo")
        .setDescription("Infos d'un membre")
        .addUserOption(o => o.setName("utilisateur").setDescription("Le membre (défaut: toi)").setRequired(false)).toJSON(),
      new SlashCommandBuilder().setName("nova-serverinfo").setDescription("Infos du serveur").toJSON(),
      new SlashCommandBuilder().setName("nova-rules")
        .setDescription("Gérer les règles du serveur")
        .addStringOption(o => o.setName("action").setDescription("Action").setRequired(true)
          .addChoices(
            { name: "add — Ajouter", value: "add" },
            { name: "show — Voir", value: "show" },
            { name: "clear — Effacer toutes (Admin)", value: "clear" }
          ))
        .addStringOption(o => o.setName("contenu").setDescription("Contenu (pour action: add)").setRequired(false)).toJSON(),
      new SlashCommandBuilder().setName("nova-links-add")
        .setDescription("Enregistrer un lien")
        .addStringOption(o => o.setName("label").setDescription("Nom du lien").setRequired(true))
        .addStringOption(o => o.setName("url").setDescription("L'URL").setRequired(true)).toJSON(),
      new SlashCommandBuilder().setName("nova-links-delete")
        .setDescription("Supprimer un lien")
        .addIntegerOption(o => o.setName("id").setDescription("ID du lien").setRequired(true)).toJSON(),
      new SlashCommandBuilder().setName("nova-links-look").setDescription("Voir tous les liens").toJSON(),
    ];

    const rest = new REST().setToken(token);
    try {
      await rest.put(Routes.applicationCommands(c.user.id), { body: commands });
      logger.info("NOVA slash commands registered globally");
    } catch (err) { logger.error("Failed to register NOVA commands", err); }

    for (const [, guild] of c.guilds.cache) await applySlowmodeToAll(guild);
  });

  client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    const cmd = interaction as ChatInputCommandInteraction;
    try {
      switch (cmd.commandName) {
        case "nova-help":         await handleNovaHelp(cmd); break;
        case "nova-setlogs":      await handleNovaSetlogs(cmd, client); break;
        case "nova-ask":          await handleNovaAsk(cmd); break;
        case "nova-ban":          await handleNovaBan(cmd, client); break;
        case "nova-kick":         await handleNovaKick(cmd, client); break;
        case "nova-mute":         await handleNovaMute(cmd, client); break;
        case "nova-clear":        await handleNovaClear(cmd, client); break;
        case "nova-ping":         await handleNovaPing(cmd); break;
        case "nova-userinfo":     await handleNovaUserinfo(cmd); break;
        case "nova-serverinfo":   await handleNovaServerinfo(cmd); break;
        case "nova-rules":        await handleNovaRules(cmd); break;
        case "nova-links-add":    await handleNovaLinksAdd(cmd); break;
        case "nova-links-delete": await handleNovaLinksDelete(cmd); break;
        case "nova-links-look":   await handleNovaLinksLook(cmd); break;
      }
    } catch (err) {
      logger.error("Command handler error", err, cmd.commandName);
      const reply = { content: "Erreur lors de l'exécution de la commande.", ephemeral: true };
      try { if (cmd.replied || cmd.deferred) await cmd.followUp(reply); else await cmd.reply(reply); } catch {}
    }
  });

  client.on(Events.MessageCreate, async (message) => {
    if (!message.guild || message.author.bot) return;
    const content = message.content;
    const member = message.member;
    const botId = client.user?.id;

    if (botId && content.includes(`<@${botId}>`)) {
      const question = content.replace(`<@${botId}>`, "").trim();
      if (!question) { await message.reply("Oui ? Pose-moi une question !"); return; }
      try {
        await message.channel.sendTyping();
        const answer = await askClaude(message.channelId, question, message.author.username);
        const chunks = splitLongMessage(answer);
        await message.reply(chunks[0]);
        for (let i = 1; i < chunks.length; i++) {
          if ("send" in message.channel) await message.channel.send(chunks[i]);
        }
      } catch (err) {
        const detail = err instanceof Error ? err.message : String(err);
        logger.error("AI mention response error", err, detail);
        await message.reply(`Erreur IA : \`${detail.slice(0, 300)}\``);
      }
      return;
    }

    if (isSpamming(message.author.id)) {
      await warnAndDelete(client, message, "spam détecté");
      if (member) await timeoutMember(client, member, "Spam", 5 * 60 * 1000); return;
    }
    if (containsEveryoneSpam(content)) {
      await warnAndDelete(client, message, "@everyone / @here interdit");
      if (member) await timeoutMember(client, member, "@everyone interdit", 10 * 60 * 1000); return;
    }
    if (containsLink(content)) {
      await warnAndDelete(client, message, "liens interdits");
      if (member) await timeoutMember(client, member, "Envoi de lien", 5 * 60 * 1000); return;
    }
    if (containsInsult(content)) {
      await warnAndDelete(client, message, "langage interdit (insulte)");
      if (member) await timeoutMember(client, member, "Insulte", 10 * 60 * 1000); return;
    }
  });

  client.on(Events.MessageUpdate, async (_old, message) => {
    if (!message.guild || !message.author || message.author.bot || !message.content) return;
    const content = message.content;
    const member = message.member;
    if (containsLink(content) || containsInsult(content) || containsEveryoneSpam(content)) {
      await warnAndDelete(client, message as Message, "contenu interdit (message modifié)");
      if (member) await timeoutMember(client, member, "Contenu interdit après modification", 5 * 60 * 1000);
    }
  });

  client.on(Events.GuildCreate, async (guild) => { await applySlowmodeToAll(guild); });

  client.on(Events.ChannelCreate, async (channel) => {
    if (
      channel.type === ChannelType.GuildText ||
      channel.type === ChannelType.GuildForum ||
      channel.type === ChannelType.GuildAnnouncement
    ) {
      try { await (channel as TextChannel).setRateLimitPerUser(SLOWMODE_SECONDS, "AutoMod: slowmode permanent"); } catch {}
    }
  });

  client.on(Events.GuildAuditLogEntryCreate, async (entry, guild) => {
    const { action, executorId } = entry;
    if (!executorId) return;
    const nukeMap: Partial<Record<AuditLogEvent, string>> = {
      [AuditLogEvent.MemberBanAdd]: "ban en masse",
      [AuditLogEvent.MemberKick]: "kick en masse",
      [AuditLogEvent.ChannelDelete]: "suppression de salon",
      [AuditLogEvent.RoleDelete]: "suppression de rôle",
      [AuditLogEvent.WebhookCreate]: "création de webhook",
      [AuditLogEvent.ChannelOverwriteCreate]: "modification de permissions en masse",
    };
    const actionName = nukeMap[action as AuditLogEvent];
    if (actionName) await handleAntiNuke(client, guild, executorId, actionName);
  });

  client.on(Events.Error, (err) => { logger.error("NOVA bot error", err); });
  client.login(token).catch(err => { logger.error("Failed to login NOVA bot", err); });

  return client;
}
