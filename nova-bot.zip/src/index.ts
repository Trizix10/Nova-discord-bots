import { startModerationBot } from "./bot.js";
import { logger } from "./logger.js";

try {
  logger.info("Démarrage du bot NOVA...");
  startModerationBot();
} catch (err) {
  logger.error("Erreur fatale lors du démarrage :", err);
  process.exit(1);
}
