# NOVA Bot 🤖

NOVA est un bot Discord autonome spécialisé dans la modération automatique (AutoMod) et l'intelligence artificielle (via Claude d'Anthropic).

## Fonctionnalités

- **AutoMod H24** : Protection contre le spam, les liens, les insultes et les mentions @everyone.
- **Anti-Nuke** : Détection et sanction automatique des actions de modération massives suspectes.
- **IA Claude** : Posez des questions à l'IA avec `/nova-ask` ou en mentionnant le bot.
- **Modération** : Commandes classiques de ban, kick, mute (timeout) et clear.
- **Système de Règles & Liens** : Gérez les règles et les liens importants de votre serveur.

## Installation

### 1. Prérequis
- Node.js (v18+)
- Un token de bot Discord ([Discord Developer Portal](https://discord.com/developers/applications))
- Une clé API Anthropic ([Anthropic Console](https://console.anthropic.com/))

### 2. Configuration du Bot Discord
Sur le Discord Developer Portal, assurez-vous d'activer les **Privileged Gateway Intents** suivants :
- `Presence Intent` (Optionnel)
- `Server Members Intent` (Requis)
- `Message Content Intent` (Requis)

### 3. Installation des dépendances
```bash
npm install
```

### 4. Configuration de l'environnement
Copiez le fichier `.env.example` vers `.env` et remplissez vos informations :
```bash
cp .env.example .env
```

### 5. Initialisation de la base de données
NOVA utilise SQLite avec Drizzle ORM. Pour créer les tables :
```bash
npx drizzle-kit push
```

## Lancement

Pour lancer le bot en mode développement (utilise `tsx`) :
```bash
npm start
```

Pour compiler et lancer en production :
```bash
npm run build
node dist/index.js
```

## Commandes Slash
- `/nova-help` : Affiche l'aide
- `/nova-setlogs #salon` : Configure le salon des logs (Admin requis)
- `/nova-ask <question>` : Pose une question à l'IA
- `/nova-rules` : Gérer les règles
- `/nova-links-add` / `/nova-links-look` : Gérer les liens
- `/nova-ban` / `/nova-kick` / `/nova-mute` / `/nova-clear` : Modération
